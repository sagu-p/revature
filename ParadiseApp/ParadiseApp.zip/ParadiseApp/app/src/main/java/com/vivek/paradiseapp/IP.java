package com.vivek.paradiseapp;

public class IP {
    public static String ip="192.168.1.131";
}
