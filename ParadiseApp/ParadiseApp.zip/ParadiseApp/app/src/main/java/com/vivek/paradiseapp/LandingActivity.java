package com.vivek.paradiseapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LandingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);

        Thread myThread = new Thread() {
            @Override
            public void run() {
                try {
                    sleep(2000);

                    //Intent i = new Intent(getApplicationContext(), sec.class);
                    Intent i = new Intent(getApplicationContext(), NavigationHomeActivity.class);
                    startActivity(i);
                    finish();

                    /*if (str_email.equals("") && str_pass.equals("")) {
                        Intent i = new Intent(getApplicationContext(), First_page.class);
                        startActivity(i);
                        finish();
                    } else {


                        Intent i = new Intent(getApplicationContext(), Main_activity.class);
                        startActivity(i);
                        finish();
                    }*/
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        myThread.start();

    }
}
